﻿function ooo {

}
