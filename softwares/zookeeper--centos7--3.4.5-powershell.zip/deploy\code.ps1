﻿# ParamTest.ps1 - Show some parameter features
# Param statement must be first non-comment, non-blank line in the script
Param(
    [parameter(Mandatory=$true)]
    [alias("e")]
    $EnvironmentName,
    [parameter(Mandatory=$true)]
    [alias("d")]
    $Destination,
    [alias("u")]
    $UserName,
    [alias("p")]
    $Password)


function positional {
 Param
     (
       [parameter(Position=0, Mandatory=$True)]
       [String[]]
       $ComputerName
    ) 
}

positional

function code {
   
}

Write-Output $EnvironmentName